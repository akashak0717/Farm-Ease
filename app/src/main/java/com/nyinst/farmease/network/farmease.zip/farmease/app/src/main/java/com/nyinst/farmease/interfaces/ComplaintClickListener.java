package com.nyinst.farmease.interfaces;

import com.nyinst.farmease.model.MyComplaintModel;

public interface ComplaintClickListener {
    void onComplaintClicked(MyComplaintModel complaintModel);
}
